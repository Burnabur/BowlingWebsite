<?php 

class Reservation {
	//Constructor - Connect to Database
	private $pdo;
	private $stmt;
	private $error;
	function __construct() {
		try {
			$this->pdo = new PDO(
				"mysql:host=".DB_HOST.";dbname=".DB_NAME.";charset=".DB_CHAR, DB_USER, DB_PASS, [PDO::ATTR_ERRMODE => PDO::ERRMDOE_EXCEPTION]
			);
		} catch (Exception $ex) { ( exit($ex->getMessage()); }
	}

		//DESTRUCTOR  - CLOSE DATABASE CONNECTION
	function __destruct () {
		$this->pdo = null;
		$this->stmt = null;
	}


	//SAVE RESERVATION
	function save ($visitor_first_name, $visitor_last_name, $visitor_email, $room_preference, $total_lanes, $checkin, $visitor_time, $catering, $event_booking, $payment_choice, $visitor_message) {
		try{
			$this->stmt = $this->pdo->prepare(
				"INSERT INTO 'reservation' ('res_visitor_first_name', 'res_visitor_last_name', 'res_visitor_email', 'res_room_preference', 'res_total_lanes', 'res_checkin', 'res_visitor_time', 'res_catering', 'res_event_booking', 'res_payment_choice', 'res_visitor_message') VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
			);
			$this->stmt->execute([$visitor_first_name, $visitor_last_name, $visitor_email, $room_preference, $total_lanes, $checkin, $visitor_time, $catering, $event_booking, $payment_choice, $visitor_message]);
			return true;
		}   catch (Exception $ex) {
			$this->error = $ex->getMessage();
			return false;
			}	
	}
}

//DATABSE SETTINGS

define("DB_HOST", "localhost");
define("DB_NAME", "test");
define("DB_CHAR", "utf8");
define("DB_USER", "root");
define("DB_PASS", "");

//NEW RESERVATION OBJECT

$_RSV = new Reservation();

//TEST

echo $_RSV->save("Barnaby", "Roberts", "barnabyr22@gmail.com", "Enterprise", "4", "2021-07-18", "12:00", "Yes", "Yes", "Chèque par email", "I like cheese")
? "OK" : $_RSV->error;
